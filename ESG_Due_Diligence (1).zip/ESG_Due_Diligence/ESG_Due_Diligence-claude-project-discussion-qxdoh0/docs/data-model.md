# ESG Due Diligence Assistant — Data Model & Data Dictionary

This document describes the physical data model as implemented in `data/sample/`.
Every section names the **CSV table**, its **columns exactly as generated**, keys
(PK/FK), the current **row count**, and **sample values** drawn from the seeded
IT-sector dataset.

- **Domain of the sample data:** IT Services & Consulting — **4 concurrent M&A
  deals** (one per target), exercising the `deal_id` multi-tenancy:
  - `DEAL001` *Project Cirrus* → Novabyte Technologies Ltd (India, INR) — 2023 data breach story
  - `DEAL002` *Project Slate* → Silverline Softworks Ltd (India, INR) — ESG laggard, 6 off-track targets
  - `DEAL003` *Project Matterhorn* → Helvetia Digital AG (Switzerland, CHF) — ESG leader, clean target
  - `DEAL004` *Project Beacon* → Beacon Cloud Systems Inc (US, USD) — SEC climate gap + breach
- **Peer universe:** 14 additional fictional IT companies for benchmarking
- **Time span:** 2015–2024 (10 reporting years)
- **Scale:** ~2,800 rows across the fact/benchmark tables (metric data 1,160;
  peer benchmark 1,120) — prototype-grade, not a toy sample
- **Regenerate:** `python scripts/generate_sample_data.py` (seeded, reproducible)
- **Integrity:** all cross-table foreign keys validated — 0 orphans

Row counts below reflect the current 4-deal generated dataset. Each deal has its
own coherent storyline, so filtering any table by `deal_id` yields a complete,
self-consistent engagement.

| Layer | Tables |
|---|---|
| Reference / master (global) | esg_metric_master, metric_standard_crosswalk, regulation_master, regulatory_requirement, peer_benchmark_data, supplier_master, fx_rate_reference |
| Deal & core entities | deal_master, company_master, company_financials, facility_master |
| ESG fact tables | esg_document_register, esg_metric_data, controversy_record, supplier_esg_assessment, esg_target, certification, legal_penalty |
| Compliance & findings | compliance_assessment, esg_risk_opportunity |
| Governance, audit & access | user_master, deal_access_control, review_audit_log, data_value_history |

**24 tables total.** Deal-scoped tables carry `deal_id`; reference tables are
global and reused across engagements.

> **DD-critical additions:** `esg_target` (are commitments credible / on-track?),
> `certification` (ISO/SOC evidence + expiry), and `legal_penalty` (quantified
> liabilities feeding SPA indemnities/escrow) are the tables a reviewing partner
> asks for first. See §3.5–3.7.

---

## 1. Reference / Master Data (global)

### 1.1 `esg_metric_master.csv` — 19 rows
Canonical catalogue of ESG metrics, tuned for the IT sector.

| Column | Key | Description | Sample |
|---|---|---|---|
| metric_code | PK | Canonical internal metric id | `ENV_SCOPE2`, `ENV_DC_PUE`, `GOV_DATA_BREACH` |
| metric_name | | Human-readable name | "Scope 2 GHG Emissions (market-based)" |
| esg_pillar | | Environmental / Social / Governance | `Environmental` |
| category | | Sub-grouping | `Emissions`, `Data Centre`, `Data Privacy` |
| standard_unit | | Canonical unit | `tCO2e`, `ratio`, `%`, `count` |
| higher_is_better | | Yes/No — direction of "good" | `No` for PUE, `Yes` for renewable share |

IT-specific metrics included: `ENV_DC_PUE` (data-centre power usage effectiveness),
`ENV_EWASTE` / `ENV_EWASTE_REC_PCT` (e-waste), `SOC_ATTRITION`, `SOC_ESAT`
(engagement), `GOV_DATA_BREACH` (reportable privacy incidents).

### 1.2 `metric_standard_crosswalk.csv` — 22 rows
Maps one canonical metric to its equivalent disclosure code in each reporting standard — resolves the "one metric, many standards" problem.

| Column | Key | Description | Sample |
|---|---|---|---|
| crosswalk_id | PK | | `CW001` |
| metric_code | FK → esg_metric_master | | `ENV_SCOPE2` |
| reporting_standard | | GRI / ESRS / BRSR / SASB / ISSB | `BRSR` |
| standard_disclosure_code | | Code within that standard | `GRI 305-2`, `ESRS E1-6`, `BRSR P6 E-9` |
| standard_disclosure_name | | Label used in that standard | "Energy indirect (Scope 2) GHG emissions" |
| unit_conversion_note | | Scope/unit caveats | "Location vs market-based differ" |

### 1.3 `regulation_master.csv` — 7 rows
ESG regulations & standards in scope. IT-relevant additions: **India DPDP Act** and **EU GDPR** for data privacy.

| Column | Key | Description | Sample |
|---|---|---|---|
| regulation_id | PK | | `REG005` |
| regulation_name | | | "India DPDP Act", "EU CSRD / ESRS", "SEBI BRSR" |
| jurisdiction | | | `India`, `EU`, `Global` |
| regulatory_body | | | `SEBI`, `MeitY`, `EDPB` |
| effective_date | | | `2023-08-11` |
| applicable_industry | | | "Data fiduciaries (IT)" |
| mandatory_flag | | Yes/No | `Yes` |
| regulation_version | | | `2023 Core`, `ESRS Set 1` |
| source_url | | Official source | `https://www.sebi.gov.in/` |

### 1.4 `regulatory_requirement.csv` — 10 rows
Individual disclosure requirements decomposed from each regulation.

| Column | Key | Description | Sample |
|---|---|---|---|
| requirement_id | PK | | `REQ008` |
| regulation_id | FK → regulation_master | | `REG006` |
| requirement_code | | Clause / disclosure number | `GDPR-33`, `DPDP-8`, `ESRS-E1-6` |
| requirement_name | | | "Breach notification to SA" |
| requirement_description | | | "Notify supervisory authority within 72h" |
| required_metric_code | FK → esg_metric_master (nullable) | Metric that satisfies it | `GOV_DATA_BREACH` |
| required_document | | Evidence expected | `ESG report`, `Incident log` |
| mandatory_flag | | | `Yes` |
| compliance_frequency | | | `Annual`, `Event-based` |

### 1.5 `peer_benchmark_data.csv` — 1120 rows
Peer ESG values for the Benchmarking Agent (14 peers × 10 years × 8 comparable metrics). Global, joined by `metric_code`.

| Column | Key | Description | Sample |
|---|---|---|---|
| benchmark_record_id | PK | | `BM0001` |
| peer_company_name | | Free text (no clean ID from free sources) | "Helvetia Digital AG" |
| industry | | | "IT Services & Consulting" |
| country | | | `Switzerland` |
| reporting_year | | | `2024` |
| metric_code | FK → esg_metric_master | | `ENV_DC_PUE` |
| metric_value | | Peer value | `1.35` |
| unit | | | `ratio` |
| normalised_value | | Adjusted value | `1.35` |
| source_name | | | "Wikirate / peer ESG report" |
| source_document | | | "Helvetia Digital AG Sustainability Report 2024" |

Comparable metrics: `ENV_RENEW_PCT`, `ENV_DC_PUE`, `ENV_EWASTE_REC_PCT`,
`SOC_ATTRITION` (with a 2021–22 sector spike), `SOC_FEMALE_PCT`, `SOC_ESAT`,
`GOV_BOARD_INDEP_PCT`, `GOV_WOMEN_BOARD_PCT`.

### 1.6 `supplier_master.csv` — 12 rows
IT supply-chain dimension (cloud, hardware, staffing, e-waste, renewables).

| Column | Key | Description | Sample |
|---|---|---|---|
| supplier_id | PK | | `SUP001` |
| supplier_name | | | "Hyperscale Cloud Services Inc", "TalentBridge Staffing LLP" |
| country | | | `United States`, `Taiwan`, `India` |
| tier | | Tier 1/2/3 | `Tier 1` |
| annual_spend | | In `spend_currency` | `5600000000` |
| spend_currency | | ISO code | `INR` |
| criticality | | Materiality to Scope 3 | `High`/`Medium`/`Low` |

### 1.7 `fx_rate_reference.csv` — 50 rows
Currency conversion (5 currencies × 10 years) to the engagement base currency.

| Column | Key | Description | Sample |
|---|---|---|---|
| fx_rate_id | PK | | `FX011` |
| currency_code | | ISO code | `USD`, `EUR`, `CHF`, `INR` |
| as_of_date | | Year-end | `2024-12-31` |
| rate_to_base_currency | | INR per 1 unit | `84.0` |
| base_currency | | | `INR` |

---

## 2. Deal & Core Entity Tables

### 2.1 `deal_master.csv` — 4 rows
Top-level engagement entity — one row per deal. Everything deal-specific hangs off `deal_id`.

| Column | Key | Description | Sample |
|---|---|---|---|
| deal_id | PK | | `DEAL001` |
| target_company_id | FK → company_master | Target being diligenced | `COMP001` |
| deal_name | | Internal codename | "Project Cirrus" |
| deal_stage | | Lifecycle stage | "Due Diligence" |
| deal_team_lead | FK → user_master | | `USR001` |
| confidentiality_level | | Drives access control | `Restricted` |
| base_currency | | For FX normalization | `INR` |
| data_cutoff_date | | As-of date | `2024-12-31` |
| status | | | `Active` |

### 2.2 `company_master.csv` — 18 rows
Static company identity (4 deal targets + 14 benchmark peers = 18). Not deal-scoped — reusable across deals.

| Column | Key | Description | Sample |
|---|---|---|---|
| company_id | PK | | `COMP001` |
| company_name | | | "Novabyte Technologies Ltd" |
| parent_company | | | "Novabyte Group" |
| industry | | | "IT Services & Consulting", "Software & Cloud" |
| country | | | `India`, `Switzerland`, `United States` |

### 2.3 `company_financials.csv` — 40 rows
Yearly financials (split from company_master to fix grain). 4 targets × 10 years.

| Column | Key | Description | Sample |
|---|---|---|---|
| company_id | PK part 1, FK → company_master | | `COMP001` |
| reporting_year | PK part 2 | | `2024` |
| annual_revenue | | In reporting_currency | ~INR 32bn (2015) → ~99bn (2024) |
| employee_count | | | 14,000 → 41,000 |
| reporting_currency | | | `INR`, `CHF` |

### 2.4 `facility_master.csv` — 24 rows
IT footprint: development centres, data centres, offices.

| Column | Key | Description | Sample |
|---|---|---|---|
| facility_id | PK | | `FAC003` |
| company_id | FK → company_master | | `COMP001` |
| facility_name | | | "Pune Data Centre", "Bengaluru Development Campus" |
| facility_type | | | `Development Centre`, `Data Centre`, `Office` |
| country / city | | | India / Pune; United Kingdom / London |
| ownership_type | | | `Owned`, `Leased` |
| operational_status | | | `Active`, `Under construction` |
| employee_count | | | `16000` |

---

## 3. ESG Fact Tables (deal-scoped)

### 3.1 `esg_document_register.csv` — 52 rows
Metadata for every source document — per deal: 10 annual ESG reports + 3 other docs (annual report, policy, incident log), × 4 deals = 52.

| Column | Key | Description | Sample |
|---|---|---|---|
| document_id | PK | | `D1-DOC-INC` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| facility_id | FK → facility_master (nullable) | Facility-specific docs | (usually blank) |
| document_name | | | "Sustainability Report 2024", "Security Incident Log 2023" |
| document_type | | | `ESG report`, `annual report`, `policy`, `audit report` |
| reporting_year | | | `2023` |
| source_system | | | `Virtual Data Room`, `SharePoint` |
| file_path | | | `/vdr/d1/esg/sustainability_2024.pdf` |
| document_date | | | `2025-05-15` |
| version | | | `v4.2` |
| language | | | `English` |
| confidentiality_flag | | | `Restricted`, `Confidential`, `Internal` |
| processing_status | | | `processed`, `pending` |

### 3.2 `esg_metric_data.csv` — 1160 rows — *authoritative fact table*
All reported ESG values, across all 4 deals: company-level (19 metrics × 10 years per target) plus facility-level splits for Scope 2 / energy / water across dev centres and PUE at data centres.

| Column | Key | Description | Sample |
|---|---|---|---|
| metric_record_id | PK | | `D1-MR00001` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| facility_id | FK → facility_master (nullable) | Blank = company-level | `D1-FAC03` |
| metric_code | FK → esg_metric_master | | `ENV_SCOPE2` |
| reporting_year | | | `2024` |
| metric_value | | Normalized value | `97847.19` |
| unit | | | `tCO2e` |
| original_value | | As reported | `97847.19` |
| original_unit | | | `tCO2e` |
| estimated_flag | | Yes/No | `Yes` (early Scope 3) |
| assurance_status | | | `Assured` (2020+), `Unaudited` (pre-2020) |
| confidence_score | | LLM extraction confidence | `0.94` |
| data_quality_score | | Rule/human completeness score | `0.88` |
| extraction_method | | Agent/model version | `extract-agent-v1.2` |
| human_verified_flag | | Yes/No | `Yes` (2022+) |
| document_id | FK → esg_document_register | | `D1-DOC2024` |
| source_page | | | `47` |

Built-in trends (Novabyte/DEAL001, size 1.0): Scope 2 ~185,000 → ~96,000 tCO2e;
renewable share ~6% → ~48%; PUE ~2.07 → ~1.45; attrition spikes to ~22% in 2021.
Other deals scale by company size and ESG maturity.

### 3.3 `controversy_record.csv` — 24 rows
Raw external ESG signals (news, NGO, litigation, regulator) — the evidence the Risk Agent cites for non-metric findings.

| Column | Key | Description | Sample |
|---|---|---|---|
| controversy_id | PK | | `D1-CTRL-breach` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| source_type | | | `News`, `NGO report`, `Litigation`, `Regulator action` |
| source_name | | | "Reuters", "SEBI", "Data Protection Authority (EU)" |
| source_url | | | `https://example-news.test/d1-ctrl-breach` |
| event_date | | | `2023-...` |
| esg_pillar | | | `Governance` |
| category | | | `Data privacy`, `Labour dispute`, `Business ethics` |
| severity | | | `High`, `Medium` |
| summary | | | "Customer data breach exposes records of an enterprise client" |
| verified_flag | | | `Yes`/`No` |

### 3.4 `supplier_esg_assessment.csv` — 72 rows
Supplier ESG scores (per deal: 6 suppliers × 3 recent years, × 4 deals = 72).

| Column | Key | Description | Sample |
|---|---|---|---|
| supplier_assessment_id | PK | | `D1-SA-SUP005-2024` |
| deal_id | FK → deal_master | | `DEAL001` |
| supplier_id | FK → supplier_master | | `SUP005` |
| company_id | FK → company_master (buyer) | | `COMP001` |
| assessment_date | | | `2024-09-15` |
| environment_score / social_score / governance_score | | 0–100 | `52 / 44 / 55` |
| overall_esg_score | | Mean of the three | `50.3` |
| human_rights_risk | | | `High` (staffing supplier) |
| carbon_data_available | | Yes/No | `No` |
| audit_status | | | `Audited`, `Not audited` |
| corrective_action_status | | | `Open`, `Closed`, `Overdue` |

### 3.5 `esg_target.csv` — 32 rows
Public ESG commitments with **progress vs. actual** — the core DD credibility check. `current_value` is the latest (2024) actual; `on_track_flag` compares progress against the linear expectation.

| Column | Key | Description | Sample |
|---|---|---|---|
| target_id | PK | | `D1-TGT08` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| metric_code | FK → esg_metric_master | Metric the target governs | `ENV_SCOPE3` |
| target_name | | | "Net-zero Scope 3 by 2050" |
| target_type | | Absolute / Intensity / Net-zero | `Net-zero` |
| base_year / base_value | | Starting point | `2018` / `260000` |
| target_year / target_value | | Commitment | `2050` / `0` |
| current_value | | Latest actual | `420000` |
| progress_pct | | % of base→target gap closed | `0.0` |
| expected_pct_linear | | % expected by now (straight-line) | `18.8` |
| on_track_flag | | progress vs. expectation | `No` |
| sbti_validated_flag | | Externally validated? | `Yes`/`No` |
| status | | | `On track`, `At risk`, `Off track` |
| evidence_document_id | FK → esg_document_register | | `D1-DOC2024` |

8 target rows per deal (× 4 = 32). Off-track count varies by target ESG maturity:
the leader (Helvetia) has 1 off-track, the laggard (Silverline) 6 — so the
Benchmarking/Risk agents get a genuine spread of credibility signals.

### 3.6 `certification.csv` — 32 rows
Management-system certifications with status and expiry — standard DD evidence. For an IT target, **ISO 27001 / SOC 2** are as material as environmental certs.

| Column | Key | Description | Sample |
|---|---|---|---|
| certification_id | PK | | `D1-CERT01` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| facility_id | FK → facility_master (nullable) | Site-specific certs | `D1-FAC03` |
| certification_name | | | "ISO/IEC 27001:2022", "SOC 2 Type II" |
| standard_body | | | `ISO`, `AICPA` |
| scope | | | "Information Security Management" |
| certificate_number | | | `IS-2019-4471` |
| issue_date / expiry_date | | | `2019-03-15` / `2025-03-14` |
| status | | | `Active`, `Under review`, `Expired` |
| certifying_body | | | `BVQI`, `DNV`, `Deloitte` |

Built-in DD signals (deal-dependent): the breach deals show **ISO 27001 "Under review"**, and the ESG-laggard deals show an **expired ISO 14001** on the main campus — while the leader (Helvetia) has all certs active.

### 3.7 `legal_penalty.csv` — 16 rows
Quantified fine / litigation / settlement ledger, linked to the source controversy — feeds SPA indemnities, escrow, and provisions.

| Column | Key | Description | Sample |
|---|---|---|---|
| penalty_id | PK | | `D1-PEN01` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| controversy_id | FK → controversy_record (nullable) | Source event | `D1-CTRL-breach` |
| case_reference | | | `DPA/2023/442` |
| regulator_body | | | "Data Protection Authority (EU)", `SEBI` |
| jurisdiction | | | `EU`, `India`, `United States` |
| penalty_type | | | `Fine`, `Penalty`, `Settlement`, `Notice` |
| amount | | In `currency` | `95000000` |
| currency | | | `INR` |
| status | | | `Contingent`, `Under appeal`, `Paid`, `Open` |
| provision_booked | | Has the company reserved for it? | `Yes`/`No` |
| filed_date / resolution_date | | | `2023-11-05` / (open) |
| description | | | "Estimated GDPR fine exposure for 2023 breach" |

Built-in DD signal: exposure differs per deal (e.g. DEAL001 ≈ **₹137.5M**, DEAL004 ≈ **₹206M**), and in the breach deals the largest line — the GDPR fine — is *contingent and un-provisioned*, a classic price-chip / indemnity item.

---

## 4. Compliance & Findings Tables (deal-scoped)

### 4.1 `compliance_assessment.csv` — 200 rows
Compliance verdict per requirement per year — jurisdiction-aware (10 requirements × 5 years × 4 deals = 200). Requirements outside a target's jurisdiction are marked `Not applicable`. Encodes realistic gaps: the breach deals fail GDPR 72h notification; laggards fail Scope 3; the US target has SEC climate gaps.

| Column | Key | Description | Sample |
|---|---|---|---|
| compliance_id | PK | | `D1-CA038` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| requirement_id | FK → regulatory_requirement | | `REQ008` |
| reporting_year | | | `2023` |
| compliance_status | | | `Compliant`, `Partial`, `Non-compliant`, `Not applicable` |
| available_value | | Value reported by company | (blank in sample) |
| gap_description | | | "GDPR 72h notification missed for breach" |
| severity | | | `Critical`, `High`, `Medium`, `Low` |
| evidence_document_id | FK → esg_document_register | | `D1-DOC2023` |
| evidence_page | | | `63` |
| remediation_action | | | "Remediate per standard" |
| target_date | | | `2024-03-31` |

### 4.2 `esg_risk_opportunity.csv` — 28 rows
Final findings from the Risk & Opportunity Agent, cross-linked to evidence.

| Column | Key | Description | Sample |
|---|---|---|---|
| finding_id | PK | | `D1-FND01` |
| deal_id | FK → deal_master | | `DEAL001` |
| company_id | FK → company_master | | `COMP001` |
| finding_type | | Risk / Opportunity | `Risk` |
| esg_pillar | | | `Governance` |
| category | | | "Data privacy" |
| title | | | "2023 customer data breach with GDPR non-compliance" |
| description | | | "Breach + missed 72h GDPR notice; regulatory fine and client-loss exposure" |
| likelihood_score | | 1–5 | `4` |
| impact_score | | 1–5 | `5` |
| overall_score | | likelihood×impact/5 | `4.0` |
| financial_impact | | In financial_impact_currency | `90000000` |
| financial_impact_currency | | | `INR` |
| priority | | | `Critical`, `High`, `Medium`, `Low` |
| recommendation | | | "Quantify GDPR fine exposure; escrow/indemnity…" |
| evidence_document_id | FK → esg_document_register (nullable) | | `D1-DOC-INC` |
| evidence_controversy_id | FK → controversy_record (nullable) | | `D1-CTRL-breach` |
| status | | | `Open`, `Under review` |

---

## 5. Governance, Audit & Access Control

### 5.1 `user_master.csv` — 8 rows
Platform users and roles.

| Column | Key | Description | Sample |
|---|---|---|---|
| user_id | PK | | `USR002` |
| user_name | | | "Marcus Feld" |
| role | | | `Deal Lead`, `Reviewer`, `Analyst`, `Admin` |
| email | | | `marcus.feld@example-advisory.test` |

### 5.2 `deal_access_control.csv` — 16 rows
Who can access a deal and at what level (includes one rolled-off user).

| Column | Key | Description | Sample |
|---|---|---|---|
| access_id | PK | | `AC004` |
| deal_id | FK → deal_master | | `DEAL001` |
| user_id | FK → user_master | | `USR004` |
| permission_level | | | `approve`, `edit`, `read` |
| granted_date | | | `2024-01-08` |
| revoked_date | | Nullable | `2024-11-30` |

### 5.3 `review_audit_log.csv` — 56 rows
Reviewer/approval trail (polymorphic via entity_type + entity_id).

| Column | Key | Description | Sample |
|---|---|---|---|
| audit_id | PK | | `D1-AU005` |
| entity_type | | Table reviewed | `esg_risk_opportunity`, `compliance_assessment` |
| entity_id | | Row reviewed | `D1-FND01` |
| user_id | FK → user_master | | `USR002` |
| action | | | `Edited`, `Reviewed`, `Approved` |
| action_date | | | `2024-12-08` |
| comment | | | "Reviewed for accuracy" |

### 5.4 `data_value_history.csv` — 8 rows
Restatement / correction history (polymorphic).

| Column | Key | Description | Sample |
|---|---|---|---|
| history_id | PK | | `D1-HIS1` |
| entity_type | | | `esg_metric_data` |
| entity_id | | | `D1-MR00002` |
| field_name | | | `metric_value` |
| old_value / new_value | | | `175000` / `185000` |
| changed_by | FK → user_master | | `USR003` |
| change_date | | | `2024-11-20` |
| change_reason | | | "Correction: switched to market-based Scope 2 factor" |

---

## Entity Relationship Overview

```
                          user_master ── deal_access_control
                                              |
deal_master ──┬── company_master ── company_financials
              │                  └── facility_master
              ├── esg_document_register
              ├── esg_metric_data ──── esg_metric_master ── metric_standard_crosswalk
              ├── controversy_record
              ├── supplier_esg_assessment ── supplier_master
              ├── compliance_assessment ── regulatory_requirement ── regulation_master
              └── esg_risk_opportunity ──(evidence)── esg_document_register / controversy_record

peer_benchmark_data   (global, joined by metric_code)
fx_rate_reference     (global, joined by currency_code)
review_audit_log / data_value_history  (cross-cutting, polymorphic by entity_type + entity_id)
```

**Worked evidence chain (DEAL001):** the 2023 data breach appears as a
metric spike (`GOV_DATA_BREACH` = 4 in `esg_metric_data`), a raw signal
(`D1-CTRL-breach` / `D1-CTRL-breach_reg` in `controversy_record`), a compliance
failure (GDPR 72h in `compliance_assessment`), a contingent liability
(`D1-PEN01` in `legal_penalty`), an `ISO 27001 "Under review"` row in
`certification`, and a Critical finding (`D1-FND01` in `esg_risk_opportunity`)
that cites both the incident-log document and the controversy record — so each
of the four agents has traceable inputs and outputs. The same chain exists,
with different specifics, in every deal.

---

## Agent → Table Mapping

| Agent | Reads | Writes |
|---|---|---|
| ESG Data Extraction | esg_document_register, esg_metric_master, metric_standard_crosswalk | esg_metric_data, esg_target, certification |
| Regulatory Compliance | esg_metric_data, regulation_master, regulatory_requirement | compliance_assessment |
| Benchmarking | esg_metric_data, peer_benchmark_data, company_financials, fx_rate_reference, esg_target | (benchmark deltas feeding findings) |
| Risk & Opportunity | esg_metric_data, compliance_assessment, peer_benchmark_data, controversy_record, supplier_esg_assessment, esg_target, certification, legal_penalty | esg_risk_opportunity |

---

## Build Phasing

**Phase 1 — MVP (present in sample as the spine):** deal_master, company_master,
company_financials, facility_master, esg_document_register, esg_metric_master,
esg_metric_data, regulation_master, regulatory_requirement, compliance_assessment,
peer_benchmark_data, esg_risk_opportunity.

**Phase 2 — before client demo:** metric_standard_crosswalk, controversy_record,
esg_target, certification, legal_penalty (target credibility, DD evidence, and
quantified liabilities — the tables a reviewing partner asks for first, and the
ones that most affect finding quality and citation traceability).

**Phase 3 — before production with real client data:** user_master,
deal_access_control, review_audit_log, data_value_history, supplier_master,
supplier_esg_assessment, fx_rate_reference (defensibility, multi-user, multi-currency).
