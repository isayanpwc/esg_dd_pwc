"""
Sample data generator for the ESG Due Diligence Assistant  --  IT SECTOR.

Produces internally-consistent CSVs (foreign keys valid across tables) with
realistic year-over-year trends for FOUR fictional IT-services M&A targets
(each its own deal / engagement) plus a peer universe for benchmarking.

All companies, people, suppliers and documents here are FICTIONAL and generated
for demo/testing only. Any resemblance to real organisations is coincidental.

Scale (prototype-grade, not toy):
  * 4 deals / 4 target companies + 14 peer companies (18 total)
  * ~6 facilities per target
  * 19 ESG metrics x 10 years (2015-2024) x 4 targets, plus facility-level splits
  * Per-deal controversies, targets, certifications, legal penalties, supplier
    assessments, compliance assessments and findings

Each deal has its own coherent "story" (e.g. Deal 1: 2023 data breach ->
ISO 27001 under review -> contingent GDPR penalty -> Critical finding), and
company ESG maturity varies so leaders come out on-track and laggards off-track.

Run:  python scripts/generate_sample_data.py
Output: data/sample/*.csv
"""

import csv
import os
import random

MASTER_SEED = 42
OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "sample")
os.makedirs(OUT_DIR, exist_ok=True)

YEARS = list(range(2015, 2025))  # 2015..2024


def write_csv(name, header, rows):
    path = os.path.join(OUT_DIR, name)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"  {name:32s} {len(rows):6d} rows")


def lerp(a, b, i, n):
    return a if n <= 1 else a + (b - a) * (i / (n - 1))


def jitter(v, pct, rng):
    return v * (1 + rng.uniform(-pct, pct))


# ---------------------------------------------------------------------------
# METRIC DEFINITIONS + TRAJECTORY TEMPLATE (size-1.0 baseline)
# ---------------------------------------------------------------------------
metrics = [
    ("ENV_SCOPE1", "Scope 1 GHG Emissions", "Environmental", "Emissions", "tCO2e", "No"),
    ("ENV_SCOPE2", "Scope 2 GHG Emissions (market-based)", "Environmental", "Emissions", "tCO2e", "No"),
    ("ENV_SCOPE3", "Scope 3 GHG Emissions", "Environmental", "Emissions", "tCO2e", "No"),
    ("ENV_ENERGY", "Total Energy Consumption", "Environmental", "Energy", "MWh", "No"),
    ("ENV_RENEW_PCT", "Renewable Energy Share", "Environmental", "Energy", "%", "Yes"),
    ("ENV_DC_PUE", "Data Centre Power Usage Effectiveness", "Environmental", "Data Centre", "ratio", "No"),
    ("ENV_WATER", "Water Withdrawal", "Environmental", "Water", "ML", "No"),
    ("ENV_EWASTE", "E-waste Generated", "Environmental", "Waste", "tonnes", "No"),
    ("ENV_EWASTE_REC_PCT", "E-waste Recycled Rate", "Environmental", "Waste", "%", "Yes"),
    ("SOC_HEADCOUNT", "Total Employees", "Social", "Workforce", "count", "Yes"),
    ("SOC_FEMALE_PCT", "Female Workforce Share", "Social", "Workforce", "%", "Yes"),
    ("SOC_ATTRITION", "Voluntary Attrition Rate", "Social", "Workforce", "%", "No"),
    ("SOC_TRAIN_HRS", "Avg Training Hours per Employee", "Social", "Workforce", "hours", "Yes"),
    ("SOC_LTIFR", "Lost Time Injury Frequency Rate", "Social", "Health & Safety", "per million hrs", "No"),
    ("SOC_ESAT", "Employee Engagement Score", "Social", "Workforce", "score", "Yes"),
    ("GOV_BOARD_INDEP_PCT", "Board Independence", "Governance", "Board", "%", "Yes"),
    ("GOV_WOMEN_BOARD_PCT", "Women on Board", "Governance", "Board", "%", "Yes"),
    ("GOV_DATA_BREACH", "Reportable Data/Privacy Incidents", "Governance", "Data Privacy", "count", "No"),
    ("GOV_ETHICS_CASES", "Ethics Cases Reported", "Governance", "Ethics", "count", "No"),
]
METRIC_UNIT = {m[0]: m[4] for m in metrics}
HIGHER_BETTER = {m[0]: (m[5] == "Yes") for m in metrics}

# (2015 value, 2024 value) for a size-1.0 company
TRAJ = {
    "ENV_SCOPE1": (12000, 9500), "ENV_SCOPE2": (185000, 96000), "ENV_SCOPE3": (240000, 420000),
    "ENV_ENERGY": (320000, 610000), "ENV_RENEW_PCT": (6.0, 48.0), "ENV_DC_PUE": (2.1, 1.42),
    "ENV_WATER": (0.9, 1.6), "ENV_EWASTE": (180, 340), "ENV_EWASTE_REC_PCT": (58.0, 90.0),
    "SOC_HEADCOUNT": (14000, 41000), "SOC_FEMALE_PCT": (28.0, 39.0), "SOC_ATTRITION": (16.0, 13.5),
    "SOC_TRAIN_HRS": (24.0, 55.0), "SOC_LTIFR": (0.4, 0.1), "SOC_ESAT": (68.0, 79.0),
    "GOV_BOARD_INDEP_PCT": (40.0, 60.0), "GOV_WOMEN_BOARD_PCT": (10.0, 30.0),
    "GOV_DATA_BREACH": (1, 2), "GOV_ETHICS_CASES": (18, 26),
}
ABS_SCALE = {"ENV_SCOPE1", "ENV_SCOPE2", "ENV_SCOPE3", "ENV_ENERGY", "ENV_WATER", "ENV_EWASTE", "SOC_HEADCOUNT"}
COUNT_MILD = {"GOV_DATA_BREACH", "GOV_ETHICS_CASES"}
PCT_SPREAD = {  # how far a leader/laggard shifts each %/ratio/score metric
    "ENV_RENEW_PCT": 22, "ENV_DC_PUE": 0.35, "ENV_EWASTE_REC_PCT": 18, "SOC_FEMALE_PCT": 8,
    "SOC_ATTRITION": 6, "SOC_TRAIN_HRS": 12, "SOC_LTIFR": 0.15, "SOC_ESAT": 8,
    "GOV_BOARD_INDEP_PCT": 12, "GOV_WOMEN_BOARD_PCT": 12,
}
INT_METRICS = {"SOC_HEADCOUNT", "GOV_DATA_BREACH", "GOV_ETHICS_CASES"}


def endpoints(mc, size, maturity):
    """Return (start, end) endpoints for a company given size and ESG maturity (-1..1)."""
    a, b = TRAJ[mc]
    if mc in ABS_SCALE:
        return a * size, b * size
    if mc in COUNT_MILD:
        s = size ** 0.5
        return a * s, b * s
    spread = PCT_SPREAD.get(mc, 0)
    shift = maturity * spread * (1 if HIGHER_BETTER[mc] else -1)
    return a + shift, b + shift


# ---------------------------------------------------------------------------
# GLOBAL REFERENCE TABLES
# ---------------------------------------------------------------------------
write_csv(
    "esg_metric_master.csv",
    ["metric_code", "metric_name", "esg_pillar", "category", "standard_unit", "higher_is_better"],
    [list(m) for m in metrics],
)

crosswalk = [
    ("ENV_SCOPE1", "GRI", "GRI 305-1", "Direct (Scope 1) GHG emissions", ""),
    ("ENV_SCOPE1", "ESRS", "ESRS E1-6", "Gross Scope 1 GHG emissions", ""),
    ("ENV_SCOPE1", "BRSR", "BRSR P6 E-7", "Scope 1 emissions", "Indian GHG Programme factors"),
    ("ENV_SCOPE2", "GRI", "GRI 305-2", "Energy indirect (Scope 2) GHG emissions", "Location vs market-based differ"),
    ("ENV_SCOPE2", "ESRS", "ESRS E1-6", "Gross Scope 2 GHG emissions", ""),
    ("ENV_SCOPE3", "GRI", "GRI 305-3", "Other indirect (Scope 3) GHG emissions", ""),
    ("ENV_SCOPE3", "ESRS", "ESRS E1-6", "Gross Scope 3 GHG emissions", ""),
    ("ENV_ENERGY", "GRI", "GRI 302-1", "Energy consumption within the organization", ""),
    ("ENV_ENERGY", "BRSR", "BRSR P6 E-1", "Total energy consumption", ""),
    ("ENV_DC_PUE", "GRI", "GRI 302-3", "Energy intensity (data-centre proxy)", "Reported as PUE, not GRI-standard"),
    ("ENV_WATER", "GRI", "GRI 303-3", "Water withdrawal", ""),
    ("ENV_EWASTE", "GRI", "GRI 306-3", "Waste generated (e-waste)", ""),
    ("ENV_EWASTE", "BRSR", "BRSR P6 E-9", "E-waste generated", "Per E-Waste Mgmt Rules 2016"),
    ("SOC_HEADCOUNT", "GRI", "GRI 2-7", "Employees", ""),
    ("SOC_FEMALE_PCT", "GRI", "GRI 405-1", "Diversity of employees", ""),
    ("SOC_FEMALE_PCT", "BRSR", "BRSR P5", "Workforce diversity", ""),
    ("SOC_ATTRITION", "GRI", "GRI 401-1", "New employee hires and turnover", ""),
    ("SOC_LTIFR", "GRI", "GRI 403-9", "Work-related injuries", ""),
    ("GOV_BOARD_INDEP_PCT", "GRI", "GRI 2-9", "Governance structure and composition", ""),
    ("GOV_WOMEN_BOARD_PCT", "GRI", "GRI 405-1", "Diversity of governance bodies", ""),
    ("GOV_DATA_BREACH", "GRI", "GRI 418-1", "Customer privacy breaches", ""),
    ("GOV_DATA_BREACH", "BRSR", "BRSR P9", "Consumer data / privacy", "Aligns with DPDP Act 2023"),
]
write_csv(
    "metric_standard_crosswalk.csv",
    ["crosswalk_id", "metric_code", "reporting_standard", "standard_disclosure_code",
     "standard_disclosure_name", "unit_conversion_note"],
    [[f"CW{str(i+1).zfill(3)}", *c] for i, c in enumerate(crosswalk)],
)

regulations = [
    ("REG001", "SEBI BRSR", "India", "SEBI", "2021-05-10", "Top 1000 listed", "Yes", "2023 Core", "https://www.sebi.gov.in/"),
    ("REG002", "EU CSRD / ESRS", "EU", "European Commission", "2024-01-01", "Large & listed EU", "Yes", "ESRS Set 1", "https://finance.ec.europa.eu/"),
    ("REG003", "GRI Standards", "Global", "Global Reporting Initiative", "2021-01-01", "Voluntary", "No", "GRI 2021", "https://www.globalreporting.org/"),
    ("REG004", "TCFD Recommendations", "Global", "FSB TCFD", "2017-06-29", "Voluntary / mandated in some", "No", "2021", "https://www.fsb-tcfd.org/"),
    ("REG005", "India DPDP Act", "India", "MeitY", "2023-08-11", "Data fiduciaries (IT)", "Yes", "2023", "https://www.meity.gov.in/"),
    ("REG006", "EU GDPR", "EU", "EDPB", "2018-05-25", "Processors of EU data", "Yes", "2016/679", "https://edpb.europa.eu/"),
    ("REG007", "US SEC Climate Disclosure", "United States", "SEC", "2024-03-06", "US-listed", "Yes", "2024 Final Rule", "https://www.sec.gov/"),
]
write_csv(
    "regulation_master.csv",
    ["regulation_id", "regulation_name", "jurisdiction", "regulatory_body", "effective_date",
     "applicable_industry", "mandatory_flag", "regulation_version", "source_url"],
    [list(r) for r in regulations],
)

# requirement -> (regulation, code, name, desc, metric, doc, mandatory, freq, jurisdiction)
requirements = [
    ("REQ001", "REG001", "BRSR-P6-7", "GHG emissions disclosure", "Disclose Scope 1 and Scope 2 emissions", "ENV_SCOPE2", "ESG report", "Yes", "Annual", "India"),
    ("REQ002", "REG001", "BRSR-P6-9", "E-waste disclosure", "Disclose e-waste generated and recycled", "ENV_EWASTE", "ESG report", "Yes", "Annual", "India"),
    ("REQ003", "REG001", "BRSR-P5", "Workforce diversity", "Disclose female workforce share", "SOC_FEMALE_PCT", "ESG report", "Yes", "Annual", "India"),
    ("REQ004", "REG001", "BRSR-P3", "Employee wellbeing", "Disclose attrition and training", "SOC_ATTRITION", "ESG report", "Yes", "Annual", "India"),
    ("REQ005", "REG002", "ESRS-E1-6", "Scope 1/2/3 emissions", "Disclose gross emissions all scopes", "ENV_SCOPE3", "ESG report", "Yes", "Annual", "EU"),
    ("REQ006", "REG002", "ESRS-E1-5", "Energy consumption", "Disclose total energy and renewable share", "ENV_RENEW_PCT", "ESG report", "Yes", "Annual", "EU"),
    ("REQ007", "REG005", "DPDP-8", "Data breach notification", "Report reportable personal-data breaches", "GOV_DATA_BREACH", "Incident log", "Yes", "Event-based", "India"),
    ("REQ008", "REG006", "GDPR-33", "Breach notification to SA", "Notify supervisory authority within 72h", "GOV_DATA_BREACH", "Incident log", "Yes", "Event-based", "EU"),
    ("REQ009", "REG004", "TCFD-GOV-a", "Board climate oversight", "Describe board oversight of climate risks", "GOV_BOARD_INDEP_PCT", "Governance report", "No", "Annual", "Global"),
    ("REQ010", "REG007", "SEC-CL-1502", "Climate risk & GHG disclosure", "Disclose material climate risks and Scope 1/2", "ENV_SCOPE1", "10-K", "Yes", "Annual", "United States"),
]
write_csv(
    "regulatory_requirement.csv",
    ["requirement_id", "regulation_id", "requirement_code", "requirement_name",
     "requirement_description", "required_metric_code", "required_document",
     "mandatory_flag", "compliance_frequency"],
    [list(r[:9]) for r in requirements],
)
REQ_JURIS = {r[0]: r[9] for r in requirements}

# Shared supplier pool
suppliers = [
    ("SUP001", "Hyperscale Cloud Services Inc", "United States", "Tier 1", 5600000000, "INR", "High"),
    ("SUP002", "Meridian Server Hardware Co", "Taiwan", "Tier 1", 3400000000, "INR", "High"),
    ("SUP003", "Bengaluru Facilities Mgmt Pvt Ltd", "India", "Tier 1", 780000000, "INR", "Medium"),
    ("SUP004", "GreenGrid Power (PPA)", "India", "Tier 1", 1900000000, "INR", "High"),
    ("SUP005", "TalentBridge Staffing LLP", "India", "Tier 2", 2200000000, "INR", "Medium"),
    ("SUP006", "Recyktron E-waste Handlers", "India", "Tier 2", 90000000, "INR", "Low"),
    ("SUP007", "Nimbus Colocation Ltd", "Germany", "Tier 1", 4100000000, "INR", "High"),
    ("SUP008", "Apex Network Devices Inc", "United States", "Tier 2", 1200000000, "INR", "Medium"),
    ("SUP009", "SolarEdge Energy Pvt Ltd", "India", "Tier 1", 1500000000, "INR", "High"),
    ("SUP010", "Contour BPO Services", "Philippines", "Tier 2", 980000000, "INR", "Medium"),
    ("SUP011", "Ironwood Cabling Co", "China", "Tier 3", 210000000, "INR", "Low"),
    ("SUP012", "Zenith Travel Management", "India", "Tier 2", 640000000, "INR", "Low"),
]
write_csv(
    "supplier_master.csv",
    ["supplier_id", "supplier_name", "country", "tier", "annual_spend", "spend_currency", "criticality"],
    [list(s) for s in suppliers],
)

# FX
fx_rows = []
fx_id = 1
fx_profiles = {"INR": 1.0, "USD": (66, 84), "EUR": (74, 90), "CHF": (68, 93), "GBP": (95, 106)}
for cur, spec in fx_profiles.items():
    for yi, yr in enumerate(YEARS):
        rate = 1.0 if cur == "INR" else round(lerp(spec[0], spec[1], yi, len(YEARS)), 2)
        fx_rows.append([f"FX{str(fx_id).zfill(3)}", cur, f"{yr}-12-31", rate, "INR"])
        fx_id += 1
write_csv(
    "fx_rate_reference.csv",
    ["fx_rate_id", "currency_code", "as_of_date", "rate_to_base_currency", "base_currency"],
    fx_rows,
)

# ---------------------------------------------------------------------------
# COMPANY UNIVERSE
# ---------------------------------------------------------------------------
# 4 targets (each a deal) + 14 peers used for benchmarking.
targets_profiles = [
    # id, name, parent, sector, country, currency, size, maturity, breach_year, attrition_years, iso27001, lapsed_env_cert, sec_gap
    ("COMP001", "Novabyte Technologies Ltd", "Novabyte Group", "IT Services & Consulting", "India", "INR", 1.0, 0.0, 2023, [2021, 2022], "Under review", True, False),
    ("COMP002", "Silverline Softworks Ltd", "", "IT Services & Consulting", "India", "INR", 0.6, -0.7, None, [2021, 2022, 2023], "Active", True, False),
    ("COMP003", "Helvetia Digital AG", "", "IT Services & Consulting", "Switzerland", "CHF", 2.1, 0.9, None, [2022], "Active", False, False),
    ("COMP004", "Beacon Cloud Systems Inc", "Beacon Holdings", "Software & Cloud", "United States", "USD", 1.5, 0.2, 2022, [2022], "Active", False, True),
]
peer_defs = [
    ("COMP101", "Silverline Softworks Ltd", "IT Services & Consulting", "India", 0.55),
    ("COMP102", "Trilokya Infotech Ltd", "IT Services & Consulting", "India", -0.6),
    ("COMP103", "Helvetia Digital AG", "IT Services & Consulting", "Switzerland", 0.9),
    ("COMP104", "Beacon Cloud Systems Inc", "Software & Cloud", "United States", 0.3),
    ("COMP105", "Meridian Systems India Ltd", "IT Services & Consulting", "India", 0.1),
    ("COMP106", "Northgate Software plc", "Software & Cloud", "United Kingdom", 0.4),
    ("COMP107", "Auroville Analytics Ltd", "IT Services & Consulting", "India", -0.3),
    ("COMP108", "Rhein Cloud GmbH", "Software & Cloud", "Germany", 0.7),
    ("COMP109", "Pacific Byte Corp", "IT Services & Consulting", "United States", -0.1),
    ("COMP110", "Deccan Digital Ltd", "IT Services & Consulting", "India", -0.5),
    ("COMP111", "Nimbus Technologies Ltd", "Software & Cloud", "India", 0.2),
    ("COMP112", "Cortex Consulting AG", "IT Services & Consulting", "Switzerland", 0.6),
    ("COMP113", "Blue Meridian Softworks", "Software & Cloud", "United States", 0.5),
    ("COMP114", "Ganges Infotech Ltd", "IT Services & Consulting", "India", -0.4),
]

company_master_rows = [[p[0], p[1], p[2], p[3], p[4]] for p in targets_profiles]
for pd_ in peer_defs:
    company_master_rows.append([pd_[0], pd_[1], "", pd_[2], pd_[3]])
write_csv(
    "company_master.csv",
    ["company_id", "company_name", "parent_company", "industry", "country"],
    company_master_rows,
)

# ---------------------------------------------------------------------------
# PEER BENCHMARK DATA (global) — 14 peers x 10 years x 8 comparable metrics
# ---------------------------------------------------------------------------
BENCH_METRICS = ["ENV_RENEW_PCT", "ENV_DC_PUE", "ENV_EWASTE_REC_PCT", "SOC_ATTRITION",
                 "SOC_FEMALE_PCT", "SOC_ESAT", "GOV_BOARD_INDEP_PCT", "GOV_WOMEN_BOARD_PCT"]
bench_rows = []
bench_id = 1
for cid, name, sector, country, maturity in peer_defs:
    rng = random.Random(hash(cid) & 0xFFFFFFFF)
    for yi, yr in enumerate(YEARS):
        for mc in BENCH_METRICS:
            a, b = endpoints(mc, 1.0, maturity)
            val = lerp(a, b, yi, len(YEARS))
            if mc == "SOC_ATTRITION" and yr in (2021, 2022):
                val *= 1.35
            val = round(jitter(val, 0.04, rng), 2)
            bench_rows.append([
                f"BM{str(bench_id).zfill(5)}", name, sector, country, yr, mc, val,
                METRIC_UNIT[mc], val, "Wikirate / peer ESG report", f"{name} Sustainability Report {yr}",
            ])
            bench_id += 1
write_csv(
    "peer_benchmark_data.csv",
    ["benchmark_record_id", "peer_company_name", "industry", "country", "reporting_year",
     "metric_code", "metric_value", "unit", "normalised_value", "source_name", "source_document"],
    bench_rows,
)

# ---------------------------------------------------------------------------
# USERS (shared) + accumulators for per-deal tables
# ---------------------------------------------------------------------------
users = [
    ("USR001", "Ananya Rao", "Deal Lead", "ananya.rao@example-advisory.test"),
    ("USR002", "Marcus Feld", "Reviewer", "marcus.feld@example-advisory.test"),
    ("USR003", "Priya Nair", "Analyst", "priya.nair@example-advisory.test"),
    ("USR004", "David Okoro", "Analyst", "david.okoro@example-advisory.test"),
    ("USR005", "System Admin", "Admin", "admin@example-advisory.test"),
    ("USR006", "Lena Duarte", "Deal Lead", "lena.duarte@example-advisory.test"),
    ("USR007", "Sanjay Iyer", "Reviewer", "sanjay.iyer@example-advisory.test"),
    ("USR008", "Grace Kim", "Analyst", "grace.kim@example-advisory.test"),
]
write_csv("user_master.csv", ["user_id", "user_name", "role", "email"], [list(u) for u in users])

deal_rows, fin_rows, fac_rows, doc_rows, metric_rows = [], [], [], [], []
ctrl_rows, sup_assess_rows, target_rows, cert_rows, penalty_rows = [], [], [], [], []
comp_rows, find_rows, access_rows, audit_rows, history_rows = [], [], [], [], []

FAC_TYPES = ["Development Centre", "Development Centre", "Data Centre", "Office", "Development Centre", "Data Centre"]
CITY_BY_COUNTRY = {
    "India": ["Bengaluru", "Hyderabad", "Pune", "Chennai", "Noida", "Mumbai"],
    "Switzerland": ["Zurich", "Geneva", "Basel", "Bern", "Lausanne", "Lugano"],
    "United States": ["Austin", "Seattle", "Denver", "Boston", "Phoenix", "Dallas"],
}


def build_deal(idx, prof):
    (cid, name, parent, sector, country, currency, size, maturity,
     breach_year, attrition_years, iso27001_status, lapsed_env_cert, sec_gap) = prof
    dkey = f"D{idx}"
    deal_id = f"DEAL{str(idx).zfill(3)}"
    lead = "USR001" if idx % 2 == 1 else "USR006"
    reviewer = "USR002" if idx % 2 == 1 else "USR007"
    analyst = ["USR003", "USR004", "USR008"][idx % 3]
    rng = random.Random(hash(cid) & 0xFFFFFFFF)
    deal_names = {1: "Project Cirrus", 2: "Project Slate", 3: "Project Matterhorn", 4: "Project Beacon"}

    deal_rows.append([deal_id, cid, deal_names[idx], "Due Diligence", lead,
                      "Restricted", currency, "2024-12-31", "Active"])

    # ---- financials (target + itself only) ----
    rev0 = 32000000000 * size
    for yi, yr in enumerate(YEARS):
        rev = rev0 * (1.12 ** yi)
        emp = int(lerp(*endpoints("SOC_HEADCOUNT", size, maturity), yi, len(YEARS)))
        fin_rows.append([cid, yr, int(jitter(rev, 0.02, rng)), emp, currency])

    # ---- facilities ----
    cities = CITY_BY_COUNTRY.get(country, ["City1", "City2", "City3", "City4", "City5", "City6"])
    n_fac = 6
    facilities = []
    for fi in range(n_fac):
        fac_id = f"{dkey}-FAC{str(fi+1).zfill(2)}"
        status = "Under construction" if fi == n_fac - 1 else "Active"
        emp = 0 if status == "Under construction" else int(rng.uniform(400, 16000))
        ftype = FAC_TYPES[fi]
        if ftype == "Data Centre":
            emp = int(rng.uniform(120, 260))
        elif ftype == "Office":
            emp = int(rng.uniform(300, 700))
        own = "Owned" if fi in (0, 2) else "Leased"
        facilities.append((fac_id, ftype, cities[fi % len(cities)], status))
        fac_rows.append([fac_id, cid, f"{cities[fi % len(cities)]} {ftype}", ftype,
                         country, cities[fi % len(cities)], own, status, emp])
    plants = [f for f in facilities if f[1] == "Development Centre" and f[3] == "Active"]
    data_centres = [f for f in facilities if f[1] == "Data Centre" and f[3] == "Active"]

    # ---- documents ----
    doc_by_year = {}
    for yr in YEARS:
        did = f"{dkey}-DOC{yr}"
        doc_by_year[yr] = did
        doc_rows.append([did, deal_id, cid, "", f"Sustainability Report {yr}", "ESG report", yr,
                         "Virtual Data Room", f"/vdr/{dkey.lower()}/esg/sustainability_{yr}.pdf",
                         f"{yr+1}-06-30", "v1.0", "English", "Restricted", "processed"])
    doc_ar = f"{dkey}-DOC-AR24"
    doc_pol = f"{dkey}-DOC-POL"
    doc_inc = f"{dkey}-DOC-INC"
    doc_rows.append([doc_ar, deal_id, cid, "", "Annual Report FY2024", "annual report", 2024,
                     "Virtual Data Room", f"/vdr/{dkey.lower()}/fin/annual_2024.pdf", "2025-05-15", "v1.0", "English", "Restricted", "processed"])
    doc_rows.append([doc_pol, deal_id, cid, "", "Information Security & Privacy Policy", "policy", 2024,
                     "SharePoint", f"/vdr/{dkey.lower()}/gov/infosec_policy.pdf", "2024-01-10", "v4.2", "English", "Internal", "processed"])
    doc_rows.append([doc_inc, deal_id, cid, "", "Security Incident Log 2023", "audit report", 2023,
                     "Virtual Data Room", f"/vdr/{dkey.lower()}/gov/incident_log_2023.pdf", "2024-01-31", "v1.0", "English", "Confidential",
                     "pending" if idx == 1 else "processed"])

    # ---- metric data (company-level + facility splits) ----
    latest = {}
    for yi, yr in enumerate(YEARS):
        doc = doc_by_year[yr]
        for mc in TRAJ:
            a, b = endpoints(mc, size, maturity)
            val = lerp(a, b, yi, len(YEARS))
            if mc == "SOC_ATTRITION" and yr in attrition_years:
                val *= 1.55
            if mc == "GOV_DATA_BREACH" and breach_year and yr == breach_year:
                val = 4
            val = jitter(val, 0.02, rng)
            val = max(0, round(val)) if mc in INT_METRICS else round(val, 2)
            if yr == 2024:
                latest[mc] = val
            metric_rows.append([
                f"{dkey}-MR{str(yi*100 + list(TRAJ).index(mc)).zfill(5)}", deal_id, cid, "", mc, yr,
                val, METRIC_UNIT[mc], val, METRIC_UNIT[mc],
                "Yes" if (mc == "ENV_SCOPE3" and yr < 2019) else "No",
                "Assured" if yr >= 2020 else "Unaudited",
                round(rng.uniform(0.82, 0.99), 2), round(rng.uniform(0.7, 0.98), 2),
                "extract-agent-v1.2", "Yes" if yr >= 2022 else "No", doc, rng.randint(12, 88),
            ])
        # facility splits: Scope2/energy/water across dev centres; PUE at data centres
        split_targets = [(p[0], 0.6 / max(1, len(plants))) for p in plants]
        for fac_id, share in split_targets:
            for mc in ["ENV_SCOPE2", "ENV_ENERGY", "ENV_WATER"]:
                a, b = endpoints(mc, size, maturity)
                val = round(jitter(lerp(a, b, yi, len(YEARS)) * share, 0.04, rng), 2)
                metric_rows.append([
                    f"{dkey}-MRF{str(len(metric_rows)).zfill(6)}", deal_id, cid, fac_id, mc, yr,
                    val, METRIC_UNIT[mc], val, METRIC_UNIT[mc], "No",
                    "Assured" if yr >= 2020 else "Unaudited",
                    round(rng.uniform(0.8, 0.98), 2), round(rng.uniform(0.7, 0.95), 2),
                    "extract-agent-v1.2", "Yes" if yr >= 2022 else "No", doc, rng.randint(12, 88),
                ])
        for fac_id, ftype, city, status in data_centres:
            a, b = endpoints("ENV_DC_PUE", size, maturity)
            val = round(jitter(lerp(a, b, yi, len(YEARS)), 0.02, rng), 2)
            metric_rows.append([
                f"{dkey}-MRF{str(len(metric_rows)).zfill(6)}", deal_id, cid, fac_id, "ENV_DC_PUE", yr,
                val, "ratio", val, "ratio", "No", "Assured" if yr >= 2020 else "Unaudited",
                round(rng.uniform(0.8, 0.98), 2), round(rng.uniform(0.7, 0.95), 2),
                "extract-agent-v1.2", "Yes" if yr >= 2022 else "No", doc, rng.randint(12, 88),
            ])

    # ---- controversies ----
    ctrl_ids = {}
    ctrl_catalog = [
        ("labour", 2018, "News", "The Economic Times", "Class-action over alleged visa wage practices at overseas subsidiary", "Social", "Labour practices", "Medium"),
        ("ethics_gov", 2020, "NGO report", "Digital Rights Watch", "Concerns over surveillance-tech contract with government client", "Governance", "Business ethics", "Medium"),
        ("attrition", 2021, "News", "LiveMint", "Mass attrition and allegations of unpaid overtime during delivery crunch", "Social", "Labour dispute", "Medium"),
        ("insider", 2022, "Regulator action", "SEBI", "Insider-trading probe into senior executives", "Governance", "Business ethics", "High"),
        ("scope3", 2024, "NGO report", "CarbonWatch", "Scope 3 cloud emissions flagged as under-counted", "Environmental", "Disclosure quality", "Medium"),
    ]
    for tag, yr, st, sn, summ, pillar, cat, sev in ctrl_catalog:
        ctag = f"{dkey}-CTRL-{tag}"
        ctrl_ids[tag] = ctag
        ctrl_rows.append([ctag, deal_id, cid, st, sn, f"https://example-news.test/{ctag.lower()}",
                          f"{yr}-0{rng.randint(1,9)}-{rng.randint(10,28)}", pillar, cat, sev, summ,
                          "Yes" if yr <= 2022 else "No"])
    if breach_year:
        for tag, sn, cat, sev, summ, yr in [
            ("breach", "Reuters", "Data privacy", "High", "Customer data breach exposes records of an enterprise client", breach_year),
            ("breach_reg", "Data Protection Authority (EU)", "Data privacy", "High", "GDPR inquiry opened following the data breach", breach_year),
        ]:
            ctag = f"{dkey}-CTRL-{tag}"
            ctrl_ids[tag] = ctag
            ctrl_rows.append([ctag, deal_id, cid, "Regulator action" if "reg" in tag else "News", sn,
                              f"https://example-news.test/{ctag.lower()}", f"{yr}-{rng.randint(6,11):02d}-{rng.randint(10,28)}",
                              "Governance", cat, sev, summ, "No"])

    # ---- supplier assessments (deal-scoped: this target assesses its suppliers) ----
    chosen = rng.sample([s[0] for s in suppliers], 6)
    for sid in chosen:
        base = rng.uniform(45, 82) + maturity * 6
        risk = rng.choice(["Low", "Medium", "High"])
        carbon = rng.choice(["Yes", "No"])
        audit = rng.choice(["Audited", "Audited", "Not audited"])
        cap = rng.choice(["Open", "Closed", "Closed", "Overdue"])
        for yr in [2022, 2023, 2024]:
            e = round(max(20, min(95, base + (yr - 2022) * 2 + rng.uniform(-4, 4))), 1)
            s = round(max(20, min(95, base - 5 + (yr - 2022) * 2 + rng.uniform(-4, 4))), 1)
            g = round(max(20, min(95, base + 3 + (yr - 2022) * 2 + rng.uniform(-4, 4))), 1)
            sup_assess_rows.append([f"{dkey}-SA-{sid}-{yr}", deal_id, sid, cid, f"{yr}-09-15",
                                    e, s, g, round((e+s+g)/3, 1), risk, carbon, audit, cap])

    # ---- targets ----
    def cur(mc):
        return latest[mc]
    tgts = [
        ("net_zero_12", "ENV_SCOPE2", "Net-zero Scope 1+2 by 2040", "Net-zero", 2015,
         round(endpoints("ENV_SCOPE1", size, maturity)[0] + endpoints("ENV_SCOPE2", size, maturity)[0]), 2040, 0,
         round(cur("ENV_SCOPE1") + cur("ENV_SCOPE2")), "Yes", doc_by_year[2024]),
        ("renew50", "ENV_RENEW_PCT", "50% renewable electricity by 2025", "Absolute", 2015,
         round(endpoints("ENV_RENEW_PCT", size, maturity)[0], 1), 2025, 50.0, cur("ENV_RENEW_PCT"), "No", doc_by_year[2024]),
        ("scope2_30", "ENV_SCOPE2", "Scope 2 -50% by 2030 vs 2015", "Absolute", 2015,
         round(endpoints("ENV_SCOPE2", size, maturity)[0]), 2030, round(endpoints("ENV_SCOPE2", size, maturity)[0] * 0.5), cur("ENV_SCOPE2"), "Yes", doc_by_year[2024]),
        ("pue14", "ENV_DC_PUE", "Data-centre PUE <=1.40 by 2025", "Intensity", 2015,
         round(endpoints("ENV_DC_PUE", size, maturity)[0], 2), 2025, 1.40, cur("ENV_DC_PUE"), "No", doc_by_year[2024]),
        ("women_wf40", "SOC_FEMALE_PCT", "40% women in workforce by 2025", "Absolute", 2015,
         round(endpoints("SOC_FEMALE_PCT", size, maturity)[0], 1), 2025, 40.0, cur("SOC_FEMALE_PCT"), "No", doc_by_year[2024]),
        ("women_bd33", "GOV_WOMEN_BOARD_PCT", "33% women on board by 2027", "Absolute", 2015,
         round(endpoints("GOV_WOMEN_BOARD_PCT", size, maturity)[0], 1), 2027, 33.0, cur("GOV_WOMEN_BOARD_PCT"), "No", doc_by_year[2024]),
        ("ewaste100", "ENV_EWASTE_REC_PCT", "100% e-waste recycling by 2025", "Absolute", 2015,
         round(endpoints("ENV_EWASTE_REC_PCT", size, maturity)[0], 1), 2025, 100.0, cur("ENV_EWASTE_REC_PCT"), "No", doc_by_year[2024]),
        ("scope3_nz", "ENV_SCOPE3", "Net-zero Scope 3 by 2050", "Net-zero", 2018,
         round(endpoints("ENV_SCOPE3", size, maturity)[0]), 2050, 0, cur("ENV_SCOPE3"), "No", doc_by_year[2024]),
    ]
    for j, (tag, mc, tname, ttype, byr, bval, tyr, tval, cval, sbti, doc) in enumerate(tgts):
        denom = (bval - tval) if (bval - tval) != 0 else 1
        progress = round(max(0.0, min(1.0, (bval - cval) / denom)) * 100, 1)
        elapsed = round(max(0.0, min(1.0, (2024 - byr) / (tyr - byr))) * 100, 1)
        on_track = "Yes" if progress + 3 >= elapsed else "No"
        status = "On track" if on_track == "Yes" else ("Off track" if progress < elapsed - 20 else "At risk")
        target_rows.append([f"{dkey}-TGT{str(j+1).zfill(2)}", deal_id, cid, mc, tname, ttype,
                            byr, bval, tyr, tval, cval, progress, elapsed, on_track, sbti, status, doc])

    # ---- certifications ----
    certs = [
        ("ISO/IEC 27001:2022", "ISO", "Information Security Management", iso27001_status, "2025-03-14", ""),
        ("ISO 45001:2018", "ISO", "Occupational Health & Safety", "Active", "2027-02-09", ""),
        ("SOC 2 Type II", "AICPA", "Security/Availability/Confidentiality", "Active", "2024-12-31", ""),
        ("ISO 9001:2015", "ISO", "Quality Management", "Active", "2027-05-19", ""),
        ("ISO 50001:2018", "ISO", "Energy Management", "Active", "2025-08-31", data_centres[0][0] if data_centres else ""),
        ("CMMI Level 5", "ISACA/CMMI", "Software Delivery Maturity", "Active", "2026-11-14", ""),
        ("ISO 14001:2015", "ISO", "Environmental Management (data centre)", "Active", "2026-06-30", data_centres[0][0] if data_centres else ""),
        ("ISO 14001:2015", "ISO", "Environmental Management (main campus)",
         "Expired" if lapsed_env_cert else "Active", "2023-03-31" if lapsed_env_cert else "2026-09-30",
         plants[0][0] if plants else ""),
    ]
    for k, (cname, body, scope, status, expiry, fac) in enumerate(certs):
        cert_rows.append([f"{dkey}-CERT{str(k+1).zfill(2)}", deal_id, cid, fac, cname, body, scope,
                          f"{body[:2].upper()}-{2018+k}-{rng.randint(1000,9999)}",
                          f"{2018+k%6}-{rng.randint(1,12):02d}-15", expiry, status,
                          rng.choice(["DNV", "BSI", "TUV", "BVQI", "Deloitte", "KPMG"])])

    # ---- legal penalties ----
    pens = []
    if breach_year:
        pens.append((ctrl_ids.get("breach", ""), f"DPA/{breach_year}/{rng.randint(100,999)}", "Data Protection Authority (EU)", "EU", "Fine", int(80000000 * size), "Contingent", "No", f"{breach_year}-11-05", "", "Estimated GDPR fine exposure for data breach; not yet assessed"))
        pens.append((ctrl_ids.get("breach_reg", ""), f"DPA/{breach_year}/{rng.randint(100,999)}-INQ", "Data Protection Authority (EU)", "EU", "Notice", 0, "Open", "No", f"{breach_year}-12-01", "", "GDPR Article 33 inquiry into late breach notification"))
    pens.append((ctrl_ids.get("insider", ""), f"SEBI/AO/2022/{rng.randint(100,999)}", "SEBI", "India", "Penalty", int(12000000 * size), "Under appeal", "Yes", "2022-08-22", "", "Insider-trading penalty; company appealing"))
    pens.append((ctrl_ids.get("labour", ""), f"DOL/2018/{rng.randint(1000,9999)}", "US Dept of Labor", "United States", "Settlement", int(45000000 * size), "Paid", "Yes", "2018-05-14", "2019-02-10", "Settlement of visa wage-practice class action"))
    pens.append(("", f"REG/BRSR/2021/{rng.randint(10,99)}", "SEBI", "India", "Penalty", 500000, "Paid", "Yes", "2021-09-30", "2021-11-15", "Minor penalty for delayed BRSR filing"))
    for m, (ctrl, ref, body, juris, ptype, amt, status, prov, filed, resolved, desc) in enumerate(pens):
        penalty_rows.append([f"{dkey}-PEN{str(m+1).zfill(2)}", deal_id, cid, ctrl, ref, body, juris,
                             ptype, amt, currency, status, prov, filed, resolved, desc])

    # ---- compliance assessments (jurisdiction-aware, 5 years) ----
    applicable = {"Global"}
    applicable.add(country)
    if country != "EU":
        applicable.add("EU")  # most have EU clients/ops in the sample
    comp_years = [2020, 2021, 2022, 2023, 2024]
    ci = 0
    for req in requirements:
        rid, juris = req[0], req[9]
        for yr in comp_years:
            ci += 1
            comp_id = f"{dkey}-CA{str(ci).zfill(3)}"
            if juris not in applicable and juris != "Global":
                status, gap, sev = "Not applicable", "Requirement out of jurisdiction", "Low"
            else:
                # default compliant, with story-driven gaps
                status, gap, sev = "Compliant", "", "Low"
                if rid == "REQ005":  # Scope 3
                    if maturity < 0.5:
                        status, gap, sev = "Non-compliant", "Scope 3 cloud & purchased-services categories not reported", "High"
                if rid in ("REQ007", "REQ008") and breach_year and yr >= breach_year:
                    status, gap, sev = ("Non-compliant", "GDPR 72h notification missed for breach", "Critical") if rid == "REQ008" else ("Partial", "DPDP breach reported late", "High")
                if rid == "REQ006" and maturity < 0 and yr < 2024:
                    status, gap, sev = "Partial", "Renewable share disclosed; energy intensity per FTE missing", "Medium"
                if rid == "REQ010" and sec_gap:
                    status, gap, sev = "Partial", "SEC climate risk narrative incomplete; Scope 1/2 assured only from 2022", "High"
                if rid == "REQ004" and maturity < -0.3:
                    status, gap, sev = "Partial", "Attrition disclosed at group level only", "Medium"
            comp_rows.append([comp_id, deal_id, cid, rid, yr, status, "", gap, sev,
                              doc_by_year.get(yr, ""), rng.randint(20, 95),
                              "Remediate per standard" if status not in ("Compliant", "Not applicable") else "",
                              f"{yr+1}-03-31" if status not in ("Compliant", "Not applicable") else ""])

    # ---- findings ----
    findings = []
    if breach_year:
        findings.append(("Risk", "Governance", "Data privacy", f"{breach_year} customer data breach with GDPR non-compliance",
                         "Breach + missed 72h GDPR notice; regulatory fine and client-loss exposure", 4, 5, int(90000000*size), "Critical",
                         "Quantify GDPR fine exposure; escrow/indemnity; remediate incident response", doc_inc, ctrl_ids.get("breach", "")))
        findings.append(("Risk", "Governance", "Certifications", "ISO 27001 certification under review after breach",
                         "Info-security cert 'Under review' post-breach; a lapse would breach client contract terms", 3, 4, int(20000000*size), "High",
                         "Confirm re-certification path; check client-contract security clauses", doc_pol, ctrl_ids.get("breach", "")))
    if maturity < 0.5:
        findings.append(("Risk", "Environmental", "Scope 3 disclosure", "Incomplete Scope 3 (cloud & purchased services) blocks CSRD",
                         "Largest emissions category unreported; blocks ESRS E1 assurance post-deal", 4, 4, int(22000000*size), "High",
                         "Budget Scope 3 cloud-emissions build in first 100 days", doc_by_year[2024], ctrl_ids.get("scope3", "")))
    findings.append(("Risk", "Social", "Talent retention", "Attrition spike and delivery-crunch labour allegations",
                     "Attrition wave + overtime claims raise integration & margin risk", 3, 4, int(30000000*size), "High",
                     "Retention pool for key talent; review overtime practices", doc_by_year[2024], ctrl_ids.get("attrition", "")))
    findings.append(("Risk", "Governance", "Business ethics", "Insider-trading probe into senior executives",
                     "SEBI probe creates leadership-continuity and reputational risk", 3, 4, int(18000000*size), "High",
                     "Confirm probe status; key-person and reps-warranties cover", doc_by_year[2022], ctrl_ids.get("insider", "")))
    if sec_gap:
        findings.append(("Risk", "Environmental", "Climate disclosure", "SEC climate disclosure gaps for US listing",
                         "Incomplete climate risk narrative and late Scope 1/2 assurance under SEC 2024 rule", 3, 3, int(15000000*size), "Medium",
                         "Close SEC climate-disclosure gaps before filing", doc_by_year[2024], ctrl_ids.get("scope3", "")))
    findings.append(("Opportunity", "Environmental", "Renewables & efficiency", "Renewable and PUE trajectory",
                     "Improving renewables and PUE; further PPA + DC efficiency upside", 4, 3, int(28000000*size), "Medium",
                     "Accelerate PPAs and data-centre efficiency for cost + rating uplift", doc_by_year[2024], ""))
    findings.append(("Opportunity", "Social", "Diversity", "Female-workforce share trajectory",
                     "Rising female share supports client DEI requirements and talent brand", 3, 3, 0, "Low",
                     "Feature DEI leadership in client and investor materials", doc_by_year[2024], ""))
    findings.append(("Opportunity", "Governance", "Board", "Improving board independence and gender diversity",
                     "Independence and women-on-board rising; supports ESG re-rating", 3, 2, 0, "Low",
                     "Highlight governance trajectory in investor narrative", doc_by_year[2024], ""))
    for n, f in enumerate(findings):
        overall = round((f[5] * f[6]) / 5, 1)
        find_rows.append([f"{dkey}-FND{str(n+1).zfill(2)}", deal_id, cid, f[0], f[1], f[2], f[3], f[4],
                          f[5], f[6], overall, f[7], currency, f[8], f[9], f[10] or "", f[11] or "", "Open"])

    # ---- access control ----
    for a_i, (uid, perm) in enumerate([(lead, "approve"), (reviewer, "approve"), (analyst, "edit"), ("USR005", "read")]):
        access_rows.append([f"{dkey}-AC{a_i+1}", deal_id, uid, perm, "2024-01-05",
                            "2024-11-30" if (a_i == 2 and idx == 1) else ""])

    # ---- audit log ----
    au = 0
    for n in range(len(findings)):
        au += 1
        audit_rows.append([f"{dkey}-AU{str(au).zfill(3)}", "esg_risk_opportunity", f"{dkey}-FND{str(n+1).zfill(2)}", analyst, "Edited", "2024-12-02", "Drafted finding"])
        au += 1
        audit_rows.append([f"{dkey}-AU{str(au).zfill(3)}", "esg_risk_opportunity", f"{dkey}-FND{str(n+1).zfill(2)}", reviewer, "Reviewed", "2024-12-08", "Reviewed for accuracy"])

    # ---- restatement history ----
    history_rows.append([f"{dkey}-HIS1", "esg_metric_data", f"{dkey}-MR00002", "metric_value", "175000", "185000", analyst, "2024-11-20", "Correction: switched to market-based Scope 2 factor"])
    history_rows.append([f"{dkey}-HIS2", "esg_risk_opportunity", f"{dkey}-FND01", "financial_impact", "85000000", "110000000", lead, "2024-12-11", "Revised financial-impact estimate after review"])


for i, prof in enumerate(targets_profiles, start=1):
    build_deal(i, prof)

# ---------------------------------------------------------------------------
# WRITE DEAL-SCOPED TABLES
# ---------------------------------------------------------------------------
write_csv("deal_master.csv",
          ["deal_id", "target_company_id", "deal_name", "deal_stage", "deal_team_lead",
           "confidentiality_level", "base_currency", "data_cutoff_date", "status"], deal_rows)
write_csv("company_financials.csv",
          ["company_id", "reporting_year", "annual_revenue", "employee_count", "reporting_currency"], fin_rows)
write_csv("facility_master.csv",
          ["facility_id", "company_id", "facility_name", "facility_type", "country", "city",
           "ownership_type", "operational_status", "employee_count"], fac_rows)
write_csv("esg_document_register.csv",
          ["document_id", "deal_id", "company_id", "facility_id", "document_name", "document_type",
           "reporting_year", "source_system", "file_path", "document_date", "version",
           "language", "confidentiality_flag", "processing_status"], doc_rows)
write_csv("esg_metric_data.csv",
          ["metric_record_id", "deal_id", "company_id", "facility_id", "metric_code", "reporting_year",
           "metric_value", "unit", "original_value", "original_unit", "estimated_flag", "assurance_status",
           "confidence_score", "data_quality_score", "extraction_method", "human_verified_flag",
           "document_id", "source_page"], metric_rows)
write_csv("controversy_record.csv",
          ["controversy_id", "deal_id", "company_id", "source_type", "source_name", "source_url",
           "event_date", "esg_pillar", "category", "severity", "summary", "verified_flag"], ctrl_rows)
write_csv("supplier_esg_assessment.csv",
          ["supplier_assessment_id", "deal_id", "supplier_id", "company_id", "assessment_date",
           "environment_score", "social_score", "governance_score", "overall_esg_score",
           "human_rights_risk", "carbon_data_available", "audit_status", "corrective_action_status"], sup_assess_rows)
write_csv("esg_target.csv",
          ["target_id", "deal_id", "company_id", "metric_code", "target_name", "target_type",
           "base_year", "base_value", "target_year", "target_value", "current_value",
           "progress_pct", "expected_pct_linear", "on_track_flag", "sbti_validated_flag",
           "status", "evidence_document_id"], target_rows)
write_csv("certification.csv",
          ["certification_id", "deal_id", "company_id", "facility_id", "certification_name",
           "standard_body", "scope", "certificate_number", "issue_date", "expiry_date",
           "status", "certifying_body"], cert_rows)
write_csv("legal_penalty.csv",
          ["penalty_id", "deal_id", "company_id", "controversy_id", "case_reference",
           "regulator_body", "jurisdiction", "penalty_type", "amount", "currency",
           "status", "provision_booked", "filed_date", "resolution_date", "description"], penalty_rows)
write_csv("compliance_assessment.csv",
          ["compliance_id", "deal_id", "company_id", "requirement_id", "reporting_year",
           "compliance_status", "available_value", "gap_description", "severity",
           "evidence_document_id", "evidence_page", "remediation_action", "target_date"], comp_rows)
write_csv("esg_risk_opportunity.csv",
          ["finding_id", "deal_id", "company_id", "finding_type", "esg_pillar", "category", "title",
           "description", "likelihood_score", "impact_score", "overall_score", "financial_impact",
           "financial_impact_currency", "priority", "recommendation", "evidence_document_id",
           "evidence_controversy_id", "status"], find_rows)
write_csv("deal_access_control.csv",
          ["access_id", "deal_id", "user_id", "permission_level", "granted_date", "revoked_date"], access_rows)
write_csv("review_audit_log.csv",
          ["audit_id", "entity_type", "entity_id", "user_id", "action", "action_date", "comment"], audit_rows)
write_csv("data_value_history.csv",
          ["history_id", "entity_type", "entity_id", "field_name", "old_value", "new_value",
           "changed_by", "change_date", "change_reason"], history_rows)

print("\nDone. Multi-deal IT-sector CSVs written to data/sample/")
